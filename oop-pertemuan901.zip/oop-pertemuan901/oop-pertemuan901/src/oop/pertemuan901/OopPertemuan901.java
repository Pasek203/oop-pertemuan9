/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oop.pertemuan901;

/**
 *
 * @MADEPASEK
 * TGL: 16 Mei 2025
 */
public class OopPertemuan901 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        mhsturunan rahman = new mhsturunan();
        rahman.setNIM("33445566");
        rahman.setJKEL("L");
        rahman.setNAMA("PASEK");
        
        System.out.println("Data Mahasiswa");
        System.out.printf("Nama          : %s\n",rahman.nama);
        System.out.printf("NIM           : %s\n",rahman.getNIM() );
        System.out.printf("Jenis Kelamin : %s\n",rahman.getJKEL() );
       
    }
    
}
